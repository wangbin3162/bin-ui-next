<template>
  <li
    :class="[
      'bin-select-item',
      {
        [`bin-select-item-disabled`]: disabled,
        [`bin-select-item-selected`]: selected && !autoComplete,
        [`bin-select-item-focus`]: isFocused,
      },
    ]"
    @click.stop="handleSelect"
    @mousedown.prevent
  >
    <slot>{{ label || value }}</slot>
  </li>
</template>

<script lang="ts">
import { defineComponent, ref, inject } from 'vue'
import { selectKey, selectEvents } from './token'

export default defineComponent({
  name: 'BOption',
  componentName: 'select-item',
  props: {
    value: {
      type: [String, Number],
      required: true,
    },
    label: [String, Number],
    disabled: Boolean,
    selected: Boolean,
    isFocused: Boolean,
  },
  setup(props, ctx) {
    const select = inject(selectKey)
    const autoComplete = ref(select?.props.autoComplete || false)
    const handleSelect = () => {
      if (props.disabled) return false
      console.log(ctx.slots.default.arguments)
      const selected = {
        value: props.value,
        label: props.label || props.value || ctx.slots.default,
      }

      ctx.emit(selectEvents.selected, selected)
      select.selectEmitter.emit(selectEvents.selected, selected)
    }
    // 通知父级更新集合
    select.optionsChild.value = [...select.optionsChild.value, { props }]
    return {
      autoComplete,
      handleSelect,
    }
  },
})
</script>
